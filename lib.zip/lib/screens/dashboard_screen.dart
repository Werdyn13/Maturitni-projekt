import 'package:flutter/material.dart';
import 'package:sidebarx/sidebarx.dart';
import 'package:pluto_grid/pluto_grid.dart';
import '../widgets/admin_app_bar_widget.dart';
import '../services/auth_service.dart';
import '../services/nastenka_service.dart';
import 'add_task_screen.dart';
import 'admin_orders_screen.dart';
import 'admin_shifts_screen.dart';
import 'admin_products_screen.dart';
import 'admin_sklad_screen.dart';
import 'manage_users_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final AuthService _authService = AuthService();
  final NastenkaService _nastenkaService = NastenkaService();
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _tasks = [];
  bool _isLoading = false;
  bool _usersLoaded = false;
  bool _tasksLoaded = false;
  
  final _controller = SidebarXController(selectedIndex: 0, extended: true);
  final _key = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      appBar: const AdminAppBarWidget(),
      backgroundColor: Colors.white,
      body: Row(
        children: [
          SidebarX(
            controller: _controller,
            theme: SidebarXTheme(
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(20),
              ),
              hoverColor: Colors.white.withOpacity(0.8),
              hoverTextStyle: const TextStyle(color: Colors.black),
              textStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
              selectedTextStyle: const TextStyle(color: Colors.white),
              itemTextPadding: const EdgeInsets.only(left: 20),
              selectedItemTextPadding: const EdgeInsets.only(left: 20),
              itemDecoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey[900]!),
              ),
              selectedItemDecoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.black.withOpacity(0.37),
                ),
                gradient: const LinearGradient(
                  colors: [Colors.black, Colors.grey],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.28),
                    blurRadius: 30,
                  )
                ],
              ),
              iconTheme: IconThemeData(
                color: Colors.white.withOpacity(0.7),
                size: 20,
              ),
              selectedIconTheme: const IconThemeData(
                color: Colors.white,
                size: 20,
              ),
              width: 60,
            ),
            extendedTheme: const SidebarXTheme(
              width: 250,
              decoration: BoxDecoration(
                color: Color(0xFF212121),
              ),
            ),
            headerBuilder: (context, extended) {
              return SizedBox(
                height: 100,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (extended)
                        const Text(
                          'Administerský panel',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        )
                      else
                        const Icon(
                          Icons.admin_panel_settings,
                          color: Colors.white,
                          size: 32,
                        ),
                    ],
                  ),
                ),
              );
            },
            items: [
              SidebarXItem(
                icon: Icons.people,
                label: 'Účty',
              ),
              SidebarXItem(
                icon: Icons.inventory,
                label: 'Produkty',
              ),
              SidebarXItem(
                icon: Icons.shopping_cart,
                label: 'Objednávky',
              ),
              SidebarXItem(
                icon: Icons.dashboard,
                label: 'Nástěnka',
              ),
              SidebarXItem(
                icon: Icons.calendar_month,
                label: 'Směny',
              ),
              SidebarXItem(
                icon: Icons.inventory_2,
                label: 'Sklad',
              ),
            ],
          ),
          Expanded(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return _buildContent(_controller.selectedIndex);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(int selectedIndex) {
    switch (selectedIndex) {
      case 0:
        return _buildAccountsTab();
      case 1:
        return _buildProductsTab();
      case 2:
        return _buildOrdersTab();
      case 3:
        return _buildNastenkaTab();
      case 4:
        return const AdminShiftsScreen();
      case 5:
        return const AdminSkladScreen();
      default:
        return const Center(child: Text('Select a tab'));
    }
  }

  Future<void> _loadUsers() async {
    setState(() => _isLoading = true);
    try {
      final users = await _authService.getAllUsers();
      setState(() {
        _users = users;
        _isLoading = false;
        _usersLoaded = true;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _usersLoaded = true;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Chyba při načítání uživatelů: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _toggleAdminStatus(String email, bool currentStatus) async {
    try {
      await _authService.toggleAdminStatus(email, !currentStatus);
      await _loadUsers();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Admin status byl úspěšně změněn'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Chyba při změně admin statusu: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  Future<void> _toggleEmployeeStatus(String email, bool currentStatus) async {
    try {
      await _authService.toggleEmployeeStatus(email, !currentStatus);
      await _loadUsers();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Status zaměstnance byl úspěšně změněn'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Chyba při změně statusu zaměstnance: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }



  Widget _buildAccountsTab() {
    if (!_usersLoaded && !_isLoading) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadUsers();
      });
    }

    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (!_usersLoaded) {
      return const Center(child: CircularProgressIndicator());
    }

    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Uživatelé',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(width: 16),
              IconButton(
                icon: const Icon(Icons.manage_accounts),
                iconSize: 32,
                color: Colors.grey[900],
                tooltip: 'Správa uživatelů',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ManageUsersScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Celkem uživatelů: ${_users.length}',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 24),
          Card(
            elevation: 2,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                child: DataTable(
                  headingRowColor: WidgetStateProperty.all(Colors.grey[100]),
                  columns: const [
                    DataColumn(
                      label: Text(
                        'Email',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Jméno',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Příjmení',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Admin',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Nastavení admina',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Zaměstnanec',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Nastavení zaměstnance',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                  rows: _users.map((user) {
                    final isAdmin = user['admin'] == true;
                    final isEmployee = user['zamestnanec'] == true;
                    final email = user['mail'] ?? '';
                    return DataRow(
                      cells: [
                        DataCell(Text(email)),
                        DataCell(Text(user['jmeno'] ?? 'N/A')),
                        DataCell(Text(user['prijmeni'] ?? 'N/A')),
                        DataCell(
                          Row(
                            children: [
                              Icon(
                                isAdmin ? Icons.check_circle : Icons.cancel,
                                color: isAdmin ? Colors.green : Colors.red,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Text(isAdmin ? 'Ano' : 'Ne'),
                            ],
                          ),
                        ),
                        DataCell(
                          Switch(
                            value: isAdmin,
                            activeThumbColor: Colors.green,
                            onChanged: (value) {
                              _toggleAdminStatus(email, isAdmin);
                            },
                          ),
                        ),
                        DataCell(
                          Row(
                            children: [
                              Icon(
                                isEmployee ? Icons.check_circle : Icons.cancel,
                                color: isEmployee ? Colors.green : Colors.red,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Text(isEmployee ? 'Ano' : 'Ne'),
                            ],
                          ),
                        ),
                        DataCell(
                          Switch(
                            value: isEmployee,
                            activeThumbColor: Colors.green,
                            onChanged: (value) {
                              _toggleEmployeeStatus(email, isEmployee);
                            },
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductsTab() {
    return const AdminProductsScreen();
  }

  Widget _buildOrdersTab() {
    return const AdminOrdersScreen();
  }

  Future<void> _loadTasks() async {
    setState(() => _isLoading = true);
    try {
      final tasks = await _nastenkaService.getAllTasks();
      setState(() {
        _tasks = tasks;
        _isLoading = false;
        _tasksLoaded = true;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _tasksLoaded = true;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Chyba při načítání úkolů: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _completeTask(int id,
      {String? opakovat, DateTime? naDen, DateTime? platnostDo}) async {
    try {
      await _nastenkaService.completeTask(id,
          opakovat: opakovat, naDen: naDen, platnostDo: platnostDo);
      await _loadTasks();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Chyba při označování úkolu: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Widget _buildNastenkaTab() {
    if (!_tasksLoaded && !_isLoading) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadTasks();
      });
    }

    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (!_tasksLoaded) {
      return const Center(child: CircularProgressIndicator());
    }

    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Nástěnka',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Celkem úkolů: ${_tasks.length}',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
              ElevatedButton.icon(
                onPressed: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AddTaskScreen(),
                    ),
                  );
                  if (result == true) {
                    _loadTasks();
                  }
                },
                icon: const Icon(Icons.add),
                label: const Text('Přidat úkol'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Expanded(
            child: _tasks.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.dashboard, size: 64, color: Colors.grey[400]),
                        const SizedBox(height: 16),
                        Text(
                          'Nástěnka je prázdná',
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _tasks.length,
                    itemBuilder: (context, index) {
                      final task = _tasks[index];
                      final date = DateTime.parse(task['na_den']);
                      
                      // Získat jméno uživatele
                      final user = task['Uzivatel'];
                      final userName = user != null
                          ? '${user['jmeno'] ?? ''} ${user['prijmeni'] ?? ''}'.trim()
                          : 'Neznámý';
                      
                      final isSplneno = task['splneno'] == true;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        elevation: 2,
                        child: ListTile(
                          leading: isSplneno
                              ? const CircleAvatar(
                                  radius: 16,
                                  backgroundColor: Colors.green,
                                  child: Icon(Icons.check,
                                      color: Colors.white, size: 18),
                                )
                              : const CircleAvatar(
                                  radius: 16,
                                  backgroundColor: Colors.black12,
                                  child: Icon(Icons.hourglass_empty,
                                      color: Colors.black54, size: 16),
                                ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: Colors.red),
                            tooltip: 'Smazat úkol',
                            onPressed: () async {
                              try {
                                await _nastenkaService
                                    .deleteTask(task['id'] as int);
                                await _loadTasks();
                              } catch (e) {
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text('Chyba: $e'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              }
                            },
                          ),
                          title: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  task['text_ukolu'] ?? '',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              if (isSplneno)
                                Container(
                                  margin: const EdgeInsets.only(left: 8),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.green.shade50,
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                        color: Colors.green.shade300),
                                  ),
                                  child: Text(
                                    'Splněno zaměstnancem',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Colors.green.shade700,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 4),
                              Text('Pro: $userName'),
                              Text('Datum: ${date.day}.${date.month}.${date.year}'),
                              if (task['opakovat'] != null && task['opakovat'] != 'Žádné') ...[
                                Text('Opakovat: ${task['opakovat']}'),
                                if (task['platnost_do'] != null)
                                  Builder(builder: (context) {
                                    final d = DateTime.parse(task['platnost_do']);
                                    return Text(
                                      'Platnost do: ${d.day}.${d.month}.${d.year}',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.orange,
                                      ),
                                    );
                                  }),
                              ],
                            ],
                          ),
                          isThreeLine: true,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showAddTaskDialog() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const AddTaskScreen(),
      ),
    );
    if (result == true) {
      _loadTasks();
    }
  }
}
